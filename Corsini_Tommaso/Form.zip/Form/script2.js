let btn = document.querySelector('input[type = "submit]');
btn.addEventListener("click", function(){
    //alert = ("ciao");
    let user = document.querySelector('input[type = "text"]').value;
    let pwd = document.querySelector('input[type = "password"]').value;
    alert("user: " + user + "- pwd: " + pwd);

    if(user && pwd){
        localStorage.setItem("username", user);
        localStorage.setItem("password", pwd);
        window.close();
    }
    else
    {
        alert("INSERIRE I DATI");
    }
})